package com.xiaolan.petfloat;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import java.util.Locale;

/**
 * 网页 ↔ 原生：
 *   PetTTS.speak(t)   让她说话
 *   PetTTS.poke()     用户碰了她
 *   PetTTS.listen()   开始一次语音识别（用系统 SpeechRecognizer，绕开 WebView 的 getUserMedia）
 */
public class TtsBridge {

    public interface Host {
        void poke();
        void listen();
    }

    public static Host host;

    private final TextToSpeech tts;

    public TtsBridge(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), this::onInit);
    }

    private void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.SIMPLIFIED_CHINESE);
            tts.setSpeechRate(1.05f);
            tts.setPitch(1.2f);
        }
    }

    @JavascriptInterface
    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "xiaolan");
    }

    @JavascriptInterface
    public void poke() {
        Host h = host;
        if (h != null) h.poke();
    }

    @JavascriptInterface
    public void listen() {
        Host h = host;
        if (h != null) h.listen();
    }
}
