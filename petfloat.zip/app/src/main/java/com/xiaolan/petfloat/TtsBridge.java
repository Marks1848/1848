package com.xiaolan.petfloat;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import java.util.Locale;

/** 给网页用的原生 TTS 桥：window.PetTTS.speak("...") */
public class TtsBridge {

    private final TextToSpeech tts;

    public TtsBridge(Context context) {
        // 用方法引用而不是 lambda：lambda 里引用还没赋值的 final 字段编不过
        tts = new TextToSpeech(context.getApplicationContext(), this::onInit);
    }

    private void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.SIMPLIFIED_CHINESE);
            tts.setSpeechRate(1.05f);
            tts.setPitch(1.2f);
        }
    }

    @JavascriptInterface
    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "xiaolan");
    }
}
