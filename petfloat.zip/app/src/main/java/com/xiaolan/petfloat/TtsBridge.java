package com.xiaolan.petfloat;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import java.util.Locale;

/**
 * 网页 ↔ 原生 的桥：
 *   window.PetTTS.speak("...")  让她说话（系统 TTS）
 *   window.PetTTS.poke()        告诉 App「用户在碰她」，用来重置待机计时
 */
public class TtsBridge {

    /** 由 MainActivity 注入：用户一碰，就把浮窗从贴边状态收回来并重新计时。 */
    public static Runnable onPoke;

    private final TextToSpeech tts;

    public TtsBridge(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), this::onInit);
    }

    private void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.SIMPLIFIED_CHINESE);
            tts.setSpeechRate(1.05f);
            tts.setPitch(1.2f);
        }
    }

    @JavascriptInterface
    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "xiaolan");
    }

    @JavascriptInterface
    public void poke() {
        Runnable r = onPoke;
        if (r != null) r.run();
    }
}
