package com.xiaolan.petfloat;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import java.util.Locale;

/** 给网页用的原生 TTS 桥：window.PetTTS.speak("...") */
public class TtsBridge {

    private final TextToSpeech tts;

    public TtsBridge(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.SIMPLIFIED_CHINESE);
                tts.setSpeechRate(1.05f);
                tts.setPitch(1.2f);
            }
        });
    }

    @JavascriptInterface
    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "xiaolan");
    }
}
