package com.xiaolan.petfloat;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import java.util.Locale;

/**
 * 网页 ↔ 原生 的桥：
 *   PetTTS.speak(t)      让她说话
 *   PetTTS.poke()        用户碰了她（重置待机计时、从贴边状态回来）
 *   PetTTS.dragBegin()   开始拖动：返回 "x,y,w,h,sw,sh,dpr"
 *   PetTTS.dragTo(x,y)   拖到屏幕绝对坐标（设备像素）
 */
public class TtsBridge {

    public interface Host {
        String dragBegin();
        void dragTo(double x, double y);
        void poke();
    }

    public static Host host;

    private final TextToSpeech tts;

    public TtsBridge(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), this::onInit);
    }

    private void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.SIMPLIFIED_CHINESE);
            tts.setSpeechRate(1.05f);
            tts.setPitch(1.2f);
        }
    }

    @JavascriptInterface
    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "xiaolan");
    }

    @JavascriptInterface
    public void poke() {
        Host h = host;
        if (h != null) h.poke();
    }

    @JavascriptInterface
    public String dragBegin() {
        Host h = host;
        return h == null ? "" : h.dragBegin();
    }

    @JavascriptInterface
    public void dragTo(double x, double y) {
        Host h = host;
        if (h != null) h.dragTo(x, y);
    }
}
