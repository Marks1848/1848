package com.xiaolan.petfloat;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.lzf.easyfloat.EasyFloat;
import com.lzf.easyfloat.enums.ShowPattern;
import com.lzf.easyfloat.enums.SidePattern;

/**
 * 小蓝浮窗。
 * 点一下按钮，就把 res/layout/float_pet.xml 里的宠物作为一个系统悬浮窗显示出来
 * （setShowPattern(ALL_TIME) + SYSTEM_ALERT_WINDOW 权限 → 能浮在任何 App 上面）。
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button button = new Button(this);
        button.setText("让小蓝浮出来");
        button.setOnClickListener(v -> showPet());
        setContentView(button);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void showPet() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            // 先去系统设置里打开「显示在其他应用上层」
            return;
        }
        EasyFloat.with(this)
                .setLayout(R.layout.float_pet)
                .setShowPattern(ShowPattern.ALL_TIME)
                .setSidePattern(SidePattern.RESULT_HORIZONTAL)
                .setDragEnable(true)
                .setTag("xiaolan")
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EasyFloat.dismiss("xiaolan");
    }
}
