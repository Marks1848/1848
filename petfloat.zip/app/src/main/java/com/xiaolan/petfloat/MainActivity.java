package com.xiaolan.petfloat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.lzf.easyfloat.EasyFloat;
import com.lzf.easyfloat.enums.ShowPattern;
import com.lzf.easyfloat.enums.SidePattern;
import com.lzf.easyfloat.interfaces.OnFloatCallbacks;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 桌宠系统悬浮窗。
 *
 * 拖动自己实现（关掉 EasyFloat 的拖拽），用 rawX/rawY 算绝对位置 —— 这样不会被它
 * 内部那套边界算得只剩中间一小块。
 *
 * 60 秒没人理 → 贴右边只露脑袋；碰一下回来。
 * 长按说话走系统 SpeechRecognizer，再把结果丢回网页。
 */
public class MainActivity extends AppCompatActivity implements TtsBridge.Host {

    private static final String TAG = "xiaolan";
    private static final long IDLE_MS = 60_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int savedX = -1;
    private int savedY = -1;
    private boolean peeked = false;
    private SpeechRecognizer recognizer;

    private int dragStartX;
    private int dragStartY;
    private float downRawX;
    private float downRawY;
    private boolean dragging;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button button = new Button(this);
        button.setText("让小蓝浮出来");
        button.setOnClickListener(v -> showPet());
        setContentView(button);

        TtsBridge.host = this;

        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void showPet() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return;
        }
        startForegroundService(new Intent(this, PetKeepAliveService.class));
        EasyFloat.with(this)
                .setLayout(R.layout.float_pet)
                .setShowPattern(ShowPattern.ALL_TIME)
                .setSidePattern(SidePattern.DEFAULT)
                .setDragEnable(false)
                .setTag(TAG)
                .registerCallbacks(new OnFloatCallbacks() {
                    @Override public void createdResult(boolean isCreated, @Nullable String msg, @Nullable View view) { }
                    @Override public void show(View view) { }
                    @Override public void hide(View view) { }
                    @Override public void dismiss() { }
                    @Override public void drag(View view, MotionEvent event) { }
                    @Override public void dragEnd(View view) { }
                    @Override public void touchEvent(View view, MotionEvent event) {
                        onFloatTouch(view, event);
                    }
                })
                .show();
        schedulePeek();
    }

    /** 自己实现的拖动：位置 = 按下时的窗口位置 + 手指位移，再夹到屏幕内。 */
    private void onFloatTouch(View view, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (peeked) {
                    restoreFromPeek();
                    dragStartX = Math.max(0, savedX);
                    dragStartY = Math.max(0, savedY);
                    savedX = -1;
                } else {
                    int[] loc = new int[2];
                    view.getLocationOnScreen(loc);
                    dragStartX = loc[0];
                    dragStartY = loc[1];
                }
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                dragging = false;
                schedulePeek();
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (!dragging && Math.abs(dx) + Math.abs(dy) < 8) break;
                dragging = true;
                DisplayMetrics dm = getResources().getDisplayMetrics();
                int maxX = Math.max(0, dm.widthPixels - view.getWidth());
                int maxY = Math.max(0, dm.heightPixels - view.getHeight());
                int nx = (int) Math.max(0, Math.min(maxX, dragStartX + dx));
                int ny = (int) Math.max(0, Math.min(maxY, dragStartY + dy));
                EasyFloat.updateFloat(TAG, nx, ny);
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                dragging = false;
                schedulePeek();
                break;
            }
            default:
                break;
        }
    }

    // ---- 语音 ----

    @Override
    public void listen() {
        runOnUiThread(() -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                inject("没给麦克风权限");
                return;
            }
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) { }
                    @Override public void onBeginningOfSpeech() { }
                    @Override public void onRmsChanged(float rmsdB) { }
                    @Override public void onBufferReceived(byte[] buffer) { }
                    @Override public void onEndOfSpeech() { }
                    @Override public void onError(int error) { inject("没听清（错误码 " + error + "）"); }
                    @Override public void onResults(Bundle results) {
                        ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (list != null && !list.isEmpty()) inject(list.get(0));
                        else inject("");
                    }
                    @Override public void onPartialResults(Bundle partial) { }
                    @Override public void onEvent(int eventType, Bundle params) { }
                });
            }
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN");
            try {
                recognizer.startListening(intent);
            } catch (Exception e) {
                inject("识别器打不开：" + e.getMessage());
            }
        });
    }

    private void inject(String text) {
        if (PetWebView.current == null) return;
        String js = "window.PetHeard(" + JSONObject.quote(text == null ? "" : text) + ")";
        PetWebView.current.post(() -> PetWebView.current.evaluateJavascript(js, null));
    }

    // ---- 待机贴边 ----

    @Override
    public void poke() {
        restoreFromPeek();
        schedulePeek();
    }

    private void schedulePeek() {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::peekAway, IDLE_MS);
    }

    private void peekAway() {
        View view = EasyFloat.getFloatView(TAG);
        if (view == null) return;
        int[] loc = new int[2];
        view.getLocationOnScreen(loc);
        savedX = loc[0];
        savedY = loc[1];
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int visible = (int) (64 * dm.density);
        EasyFloat.updateFloat(TAG, dm.widthPixels - visible, savedY);
        peeked = true;
    }

    private void restoreFromPeek() {
        if (!peeked || savedX < 0) return;
        EasyFloat.updateFloat(TAG, savedX, savedY);
        peeked = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
    }
}
