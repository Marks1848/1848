package com.xiaolan.petfloat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.lzf.easyfloat.EasyFloat;
import com.lzf.easyfloat.enums.ShowPattern;
import com.lzf.easyfloat.enums.SidePattern;

/**
 * 点按钮把桌宠做成系统悬浮窗。
 *  - 可以拖到屏幕任意位置（SidePattern.DEFAULT，不吸附边缘）；
 *  - 90 秒没人理她，她会自动贴到右边、只露半个脑袋；碰一下（网页通过 PetTTS.poke 通知）就回来。
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "xiaolan";
    private static final long IDLE_MS = 90_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int savedX = -1;
    private int savedY = -1;
    private boolean peeked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button button = new Button(this);
        button.setText("让小蓝浮出来");
        button.setOnClickListener(v -> showPet());
        setContentView(button);

        TtsBridge.onPoke = () -> {
            restoreFromPeek();
            schedulePeek();
        };

        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void showPet() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return;
        }
        startForegroundService(new Intent(this, PetKeepAliveService.class));
        EasyFloat.with(this)
                .setLayout(R.layout.float_pet)
                .setShowPattern(ShowPattern.ALL_TIME)
                .setSidePattern(SidePattern.DEFAULT)
                .setDragEnable(true)
                .setTag(TAG)
                .show();
        schedulePeek();
    }

    private void schedulePeek() {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::peekAway, IDLE_MS);
    }

    /** 没人理她：贴到屏幕右边，只露 64dp 的脑袋。 */
    private void peekAway() {
        View view = EasyFloat.getFloatView(TAG);
        if (view == null) return;
        int[] loc = new int[2];
        view.getLocationOnScreen(loc);
        savedX = loc[0];
        savedY = loc[1];
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int visible = (int) (64 * dm.density);
        EasyFloat.updateFloat(TAG, dm.widthPixels - visible, savedY);
        peeked = true;
    }

    private void restoreFromPeek() {
        if (!peeked || savedX < 0) return;
        EasyFloat.updateFloat(TAG, savedX, savedY);
        peeked = false;
        savedX = -1;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
