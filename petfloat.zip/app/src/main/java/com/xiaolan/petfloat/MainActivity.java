package com.xiaolan.petfloat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.lzf.easyfloat.EasyFloat;
import com.lzf.easyfloat.enums.ShowPattern;
import com.lzf.easyfloat.enums.SidePattern;

/**
 * 桌宠系统悬浮窗。
 *  - 拖动由网页接管（PetTTS.dragTo），所以可以拖到屏幕任意角落；
 *  - 60 秒没人理，自己贴到右边只露脑袋；碰一下回来。
 */
public class MainActivity extends AppCompatActivity implements TtsBridge.Host {

    private static final String TAG = "xiaolan";
    private static final long IDLE_MS = 60_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int savedX = -1;
    private int savedY = -1;
    private boolean peeked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Button button = new Button(this);
        button.setText("让小蓝浮出来");
        button.setOnClickListener(v -> showPet());
        setContentView(button);

        TtsBridge.host = this;

        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void showPet() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return;
        }
        startForegroundService(new Intent(this, PetKeepAliveService.class));
        EasyFloat.with(this)
                .setLayout(R.layout.float_pet)
                .setShowPattern(ShowPattern.ALL_TIME)
                .setSidePattern(SidePattern.DEFAULT)
                .setDragEnable(false)   // 拖动交给网页自己做，能精确到像素
                .setTag(TAG)
                .show();
        schedulePeek();
    }

    // ---- TtsBridge.Host ----

    @Override
    public void poke() {
        restoreFromPeek();
        schedulePeek();
    }

    @Override
    public String dragBegin() {
        View v = EasyFloat.getFloatView(TAG);
        if (v == null) return "";
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return loc[0] + "," + loc[1] + "," + v.getWidth() + "," + v.getHeight()
                + "," + dm.widthPixels + "," + dm.heightPixels + "," + dm.density;
    }

    @Override
    public void dragTo(double x, double y) {
        View v = EasyFloat.getFloatView(TAG);
        if (v == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxX = Math.max(0, dm.widthPixels - v.getWidth());
        int maxY = Math.max(0, dm.heightPixels - v.getHeight());
        int nx = (int) Math.max(0, Math.min(maxX, x));
        int ny = (int) Math.max(0, Math.min(maxY, y));
        EasyFloat.updateFloat(TAG, nx, ny);
        peeked = false;
        savedX = -1;
        schedulePeek();
    }

    // ---- 待机贴边 ----

    private void schedulePeek() {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::peekAway, IDLE_MS);
    }

    private void peekAway() {
        View view = EasyFloat.getFloatView(TAG);
        if (view == null) return;
        int[] loc = new int[2];
        view.getLocationOnScreen(loc);
        savedX = loc[0];
        savedY = loc[1];
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int visible = (int) (64 * dm.density);
        EasyFloat.updateFloat(TAG, dm.widthPixels - visible, savedY);
        peeked = true;
    }

    private void restoreFromPeek() {
        if (!peeked || savedX < 0) return;
        EasyFloat.updateFloat(TAG, savedX, savedY);
        peeked = false;
        savedX = -1;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
