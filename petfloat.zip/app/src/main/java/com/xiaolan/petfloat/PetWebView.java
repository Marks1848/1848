package com.xiaolan.petfloat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.webkit.WebSettings;
import android.webkit.WebView;

import java.io.File;

/**
 * 自动加载桌宠页面的 WebView。
 *
 * 优先读手机里的离线副本（/sdcard/dsh/dsh-pet/pet.html），
 * 没有就退回 DSH 宿主提供的 http://127.0.0.1:3187/pet。
 * 背景透明，才能叠在别的 App 上面不挡一块白板。
 */
public class PetWebView extends WebView {

    public PetWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void init() {
        setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        File offline = new File("/sdcard/dsh/dsh-pet/pet.html");
        if (offline.exists()) {
            loadUrl("file://" + offline.getAbsolutePath());
        } else {
            loadUrl("http://127.0.0.1:3187/pet");
        }
    }
}
