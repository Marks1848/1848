package com.xiaolan.petfloat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.webkit.WebSettings;
import android.webkit.WebView;

/**
 * 内置桌宠页面的 WebView：页面打在 APK 的 assets 里，不依赖 /sdcard 也不需要 DSH 在跑。
 * 页面里通过 window.PetTTS.speak() 调原生 TTS 说话。
 */
public class PetWebView extends WebView {

    public PetWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void init() {
        setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        addJavascriptInterface(new TtsBridge(getContext()), "PetTTS");
        loadUrl("file:///android_asset/pet.html");
    }
}
