package com.xiaolan.petfloat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

/** 内置页面 + 给 Activity/Service 用的静态引用。 */
public class PetWebView extends WebView {

    public static PetWebView current;

    private final WebViewAssetLoader loader;

    public PetWebView(Context context) {
        this(context, null);
    }

    public PetWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        current = this;
        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(context))
                .build();
        init();
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void init() {
        setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        addJavascriptInterface(new TtsBridge(getContext()), "PetTTS");

        setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                post(() -> request.grant(request.getResources()));
            }
        });
        loadUrl("https://appassets.androidplatform.net/assets/pet.html");
    }

    public static void call(String js) {
        PetWebView v = current;
        if (v == null) return;
        v.post(() -> v.evaluateJavascript(js, null));
    }
}
