package com.xiaolan.petfloat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

/**
 * 用 WebViewAssetLoader 把 assets 里的页面通过 https://appassets.androidplatform.net
 * 提供出来 —— 这样页面是「安全上下文」，getUserMedia（长按说话）才能用。
 * 直接 file:// 打开的话，WebView 会拒绝麦克风。
 */
public class PetWebView extends WebView {

    private final WebViewAssetLoader loader;

    public PetWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(context))
                .build();
        init();
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void init() {
        setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        // https 页面要访问 127.0.0.1 的 http 接口
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        addJavascriptInterface(new TtsBridge(getContext()), "PetTTS");

        setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                post(() -> request.grant(request.getResources()));
            }
        });

        loadUrl("https://appassets.androidplatform.net/assets/pet.html");
    }
}
