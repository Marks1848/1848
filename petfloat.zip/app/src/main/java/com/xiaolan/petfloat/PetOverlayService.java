package com.xiaolan.petfloat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.HandlerThread;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 自己实现的系统悬浮窗（不用 EasyFloat）：
 *  - 窗口位置就是屏幕绝对坐标，拖到哪就是哪，四个角都能到；
 *  - 60 秒没人理 → 贴右边只露脑袋，碰一下回来；
 *  - 原生轮询 127.0.0.1:3187/inbox，把微信/QQ 消息和日常提醒推给网页；
 *  - 长按说话用系统 SpeechRecognizer，识别结果直接问 /chat，回复推回网页。
 */
public class PetOverlayService extends Service implements TtsBridge.Host, RecognitionListener {

    private static final String CHANNEL = "xiaolan_overlay";
    private static final long IDLE_MS = 60_000L;
    private static final long POLL_MS = 8_000L;

    private WindowManager wm;
    private DragFrame root;
    private PetWebView web;
    private WindowManager.LayoutParams params;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private int savedX = -1;
    private int savedY = -1;
    private boolean peeked = false;
    private long lastSeq = 0;
    private SpeechRecognizer recognizer;
    private AudioRecord audioRecord;
    private Thread recThread;
    private ByteArrayOutputStream recBuf;
    private volatile boolean recording;
    private boolean bubbleOpen;
    private volatile boolean alive = true;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1001, buildNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(1001, buildNotification());
        }
        TtsBridge.host = this;

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = (int) (124 * dm.density);
        int h = (int) (161 * dm.density);

        root = new DragFrame(this);
        web = new PetWebView(this);
        root.addView(web, new FrameLayout.LayoutParams(w, h));

        params = new WindowManager.LayoutParams(
                w, h,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = (int) (16 * dm.density);
        params.y = (int) (dm.heightPixels * 0.55);

        wm.addView(root, params);
        schedulePeek();
        startPolling();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        alive = false;
        handler.removeCallbacksAndMessages(null);
        try { if (web != null && recognizer != null) recognizer.destroy(); } catch (Exception ignored) { }
        try { if (root != null && wm != null) wm.removeView(root); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "小蓝常驻", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("小蓝在你身边")
                .setContentText("点一下可以打开设置")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    // ---------------- 气泡（窗口临时长高，避免气泡被裁） ----------------

    @Override
    public void setBubble(boolean on) {
        handler.post(() -> {
            if (root == null) return;
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int extra = (int) (112 * dm.density);
            if (on && !bubbleOpen) {
                bubbleOpen = true;
                params.y = Math.max(0, params.y - extra);
                params.height = params.height + extra;
                wm.updateViewLayout(root, params);
            } else if (!on && bubbleOpen) {
                bubbleOpen = false;
                params.y = params.y + extra;
                params.height = Math.max(1, params.height - extra);
                wm.updateViewLayout(root, params);
            }
        });
    }

    // ---------------- 拖动 ----------------

    private class DragFrame extends FrameLayout {
        private float downX, downY;
        private int startX, startY;
        private boolean dragging;

        DragFrame(Context c) {
            super(c);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = ev.getRawX();
                    downY = ev.getRawY();
                    startX = params.x;
                    startY = params.y;
                    dragging = false;
                    onUserTouch();
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (!dragging && Math.abs(ev.getRawX() - downX) + Math.abs(ev.getRawY() - downY) > 12) {
                        dragging = true;
                    }
                    return dragging;
                default:
                    return false;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_MOVE: {
                    DisplayMetrics dm = getResources().getDisplayMetrics();
                    int maxX = Math.max(0, dm.widthPixels - params.width);
                    int maxY = Math.max(0, dm.heightPixels - params.height);
                    int nx = (int) Math.max(0, Math.min(maxX, startX + (ev.getRawX() - downX)));
                    int ny = (int) Math.max(0, Math.min(maxY, startY + (ev.getRawY() - downY)));
                    params.x = nx;
                    params.y = ny;
                    wm.updateViewLayout(this, params);
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    schedulePeek();
                    return true;
                default:
                    return true;
            }
        }
    }

    // ---------------- 待机贴边 ----------------

    private void onUserTouch() {
        if (peeked && savedX >= 0) {
            params.x = savedX;
            params.y = savedY;
            wm.updateViewLayout(root, params);
            peeked = false;
        }
        schedulePeek();
    }

    private final Runnable peekRunnable = this::peekAway;

    private void schedulePeek() {
        handler.removeCallbacks(peekRunnable);
        handler.postDelayed(peekRunnable, IDLE_MS);
    }

    private void peekAway() {
        if (root == null) return;
        savedX = params.x;
        savedY = params.y;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        params.x = dm.widthPixels - (int) (64 * dm.density);
        wm.updateViewLayout(root, params);
        peeked = true;
    }

    // ---------------- 消息轮询 ----------------

    private void startPolling() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!alive) return;
                io.execute(() -> {
                    String body = httpGet("http://127.0.0.1:3187/inbox?since=" + lastSeq);
                    if (body != null) handler.post(() -> handleInbox(body));
                });
                handler.postDelayed(this, POLL_MS);
            }
        }, 2500);
    }

    private void handleInbox(String body) {
        try {
            JSONObject o = new JSONObject(body);
            lastSeq = o.optLong("seq", lastSeq);
            JSONArray arr = o.optJSONArray("events");
            if (arr == null || arr.length() == 0) return;
            JSONObject e = arr.getJSONObject(arr.length() - 1);
            String app = e.optString("app");
            String title = e.optString("title");
            String text = e.optString("text");
            String kind = e.optString("kind");
            String head = app + (title.isEmpty() ? "" : " · " + title);
            PetWebView.call("window.PetHeardMessage(" + JSONObject.quote(head) + ","
                    + JSONObject.quote(text) + "," + JSONObject.quote(kind) + ")");
        } catch (Exception ignored) { }
    }

    // ---------------- 语音 / 对话 ----------------

    @Override
    public void poke() {
        handler.post(this::onUserTouch);
    }

    public void recStart() {
        handler.post(() -> {
            if (recording) return;
            if (androidx.core.content.ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                PetWebView.call("window.PetHeardError('没有麦克风权限')");
                return;
            }
            int minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int bufSize = Math.max(minBuf * 2, 8192);
            try {
                audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize);
            } catch (Exception e) {
                PetWebView.call("window.PetHeardError(" + JSONObject.quote("麦克风打不开：" + e.getMessage()) + ")");
                return;
            }
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                PetWebView.call("window.PetHeardError('麦克风初始化失败')");
                return;
            }
            recBuf = new ByteArrayOutputStream();
            recording = true;
            audioRecord.startRecording();
            recThread = new Thread(() -> {
                byte[] buf = new byte[4096];
                while (recording) {
                    int n = audioRecord.read(buf, 0, buf.length);
                    if (n > 0) recBuf.write(buf, 0, n);
                }
            });
            recThread.start();
            PetWebView.call("window.PetHeardListening()");
        });
    }

    public void recStop() {
        handler.post(() -> {
            if (!recording) return;
            recording = false;
            try { audioRecord.stop(); } catch (Exception ignored) { }
            try { audioRecord.release(); } catch (Exception ignored) { }
            byte[] pcm = recBuf.toByteArray();
            PetWebView.call("window.PetMicDone()");
            PetWebView.call("window.PetHeardThinking()");
            if (pcm.length < 8000) {
                PetWebView.call("window.PetHeardError('太短啦，按住久一点')");
                return;
            }
            io.execute(() -> {
                byte[] wav = pcmToWav(pcm, 16000);
                String text = postStt(wav);
                if (text == null) {
                    handler.post(() -> PetWebView.call("window.PetHeardError('听不到 DSH，它没在跑？')"));
                    return;
                }
                if (text.trim().isEmpty()) {
                    handler.post(() -> PetWebView.call("window.PetHeardError('没听清，再说一次？')"));
                    return;
                }
                handler.post(() -> PetWebView.call("window.PetHeardText(" + JSONObject.quote(text.trim()) + ")"));
                ask(text.trim());
            });
        });
    }

    private byte[] pcmToWav(byte[] pcm, int rate) {
        int len = pcm.length;
        byte[] wav = new byte[44 + len];
        long totalDataLen = len + 36;
        long byteRate = rate * 2L;
        wav[0] = 'R'; wav[1] = 'I'; wav[2] = 'F'; wav[3] = 'F';
        wav[4] = (byte) (totalDataLen & 0xff);
        wav[5] = (byte) ((totalDataLen >> 8) & 0xff);
        wav[6] = (byte) ((totalDataLen >> 16) & 0xff);
        wav[7] = (byte) ((totalDataLen >> 24) & 0xff);
        wav[8] = 'W'; wav[9] = 'A'; wav[10] = 'V'; wav[11] = 'E';
        wav[12] = 'f'; wav[13] = 'm'; wav[14] = 't'; wav[15] = ' ';
        wav[16] = 16; wav[17] = 0; wav[18] = 0; wav[19] = 0;
        wav[20] = 1; wav[21] = 0;
        wav[22] = 1; wav[23] = 0;
        wav[24] = (byte) (rate & 0xff); wav[25] = (byte) ((rate >> 8) & 0xff);
        wav[26] = 0; wav[27] = 0;
        wav[28] = (byte) (byteRate & 0xff); wav[29] = (byte) ((byteRate >> 8) & 0xff);
        wav[30] = (byte) ((byteRate >> 16) & 0xff); wav[31] = (byte) ((byteRate >> 24) & 0xff);
        wav[32] = 2; wav[33] = 0;
        wav[34] = 16; wav[35] = 0;
        wav[36] = 'd'; wav[37] = 'a'; wav[38] = 't'; wav[39] = 'a';
        wav[40] = (byte) (len & 0xff); wav[41] = (byte) ((len >> 8) & 0xff);
        wav[42] = (byte) ((len >> 16) & 0xff); wav[43] = (byte) ((len >> 24) & 0xff);
        System.arraycopy(pcm, 0, wav, 44, len);
        return wav;
    }

    private String postStt(byte[] wav) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://127.0.0.1:3187/stt").openConnection();
            c.setDoOutput(true);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/octet-stream");
            c.setConnectTimeout(2000);
            c.setReadTimeout(60000);
            c.setFixedLengthStreamingMode(wav.length);
            try (OutputStream os = c.getOutputStream()) {
                os.write(wav);
            }
            if (c.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            JSONObject o = new JSONObject(sb.toString());
            return o.optBoolean("ok", false) ? o.optString("text", "") : null;
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    @Override
    public void listen() {
        handler.post(() -> {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                PetWebView.call("window.PetHeardError('这台手机没有语音识别服务')");
                return;
            }
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(this);
            }
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN");
            try {
                recognizer.startListening(intent);
            } catch (Exception e) {
                PetWebView.call("window.PetHeardError(" + JSONObject.quote("识别器打不开：" + e.getMessage()) + ")");
            }
        });
    }

    @Override
    public void ask(String text) {
        if (text == null || text.trim().isEmpty()) return;
        io.execute(() -> {
            String body = httpGet("http://127.0.0.1:3187/chat?text=" + java.net.URLEncoder.encode(text));
            String reply = null;
            try {
                if (body != null) reply = new JSONObject(body).optString("reply", null);
            } catch (Exception ignored) { }
            final String r = reply;
            handler.post(() -> {
                if (r != null && !r.isEmpty()) {
                    PetWebView.call("window.PetHeardReply(" + JSONObject.quote(r) + ")");
                } else {
                    PetWebView.call("window.PetHeardError('听不到 DSH，它没在跑？')");
                }
            });
        });
    }

    @Override public void onReadyForSpeech(android.os.Bundle b) { }
    @Override public void onBeginningOfSpeech() { }
    @Override public void onRmsChanged(float v) { }
    @Override public void onBufferReceived(byte[] b) { }
    @Override public void onEndOfSpeech() { }
    @Override public void onPartialResults(android.os.Bundle b) { }
    @Override public void onEvent(int i, android.os.Bundle b) { }

    @Override
    public void onError(int error) {
        PetWebView.call("window.PetHeardError(" + JSONObject.quote("没听清（错误码 " + error + "）") + ")");
    }

    @Override
    public void onResults(android.os.Bundle results) {
        ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String text = (list != null && !list.isEmpty()) ? list.get(0) : "";
        if (text.isEmpty()) {
            PetWebView.call("window.PetHeardError('没听清，再说一次？')");
            return;
        }
        PetWebView.call("window.PetHeardText(" + JSONObject.quote(text) + ")");
        ask(text);
    }

    // ---------------- 工具 ----------------

    private String httpGet(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(2000);
            c.setReadTimeout(45000);
            if (c.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
