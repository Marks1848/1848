# 小蓝浮窗（EasyFloat 版）

一个最小 Android 工程：把 DSH 里的桌宠页面作为一个**系统悬浮窗**显示，
可以浮在微信、抖音、桌面上。

## 关键代码

```java
EasyFloat.with(this)
        .setLayout(R.layout.float_pet)
        .setShowPattern(ShowPattern.ALL_TIME)   // 系统浮窗（默认只在本页显示）
        .setSidePattern(SidePattern.RESULT_HORIZONTAL)
        .setDragEnable(true)
        .setTag("xiaolan")
        .show();
```

`ALL_TIME` 需要 `SYSTEM_ALERT_WINDOW` 权限：Manifest 里已声明，启动时会自动跳到授权页。

## 宠物页面从哪来

`PetWebView` 优先加载手机里的离线页面 `/sdcard/dsh/dsh-pet/pet.html`，
没有就退回 `http://127.0.0.1:3187/pet`（需要 DSH 在跑）。

## 没有电脑怎么办

1. 把这个 zip 传到一个 GitHub 仓库（手机浏览器就能上传）；
2. 在仓库里新建 `.github/workflows/build.yml`，内容用 `build-workflow.yml`；
3. push 后 Actions 自动编译，在 Artifacts 里下载 `xiaolan-apk.zip`；
4. 解压出 `app-debug.apk`，安装即可。

## 依赖

- EasyFloat 2.0.4（JitPack）
- androidx.appcompat 1.6.1
- kotlin-stdlib 1.9.22
