# 小蓝浮窗（EasyFloat 版）

把桌宠做成**系统悬浮窗**：浮在微信、抖音、桌面上，能拖、能点、会用原生 TTS 说话。

## 这一版加了什么

- **页面内置**：`app/src/main/assets/pet.html`，不再依赖 `/sdcard` 或 DSH 进程；
- **原生 TTS**：`TtsBridge` 暴露 `window.PetTTS.speak()`，网页里每句话都会念出来；
- **前台服务**：`PetKeepAliveService` 降低被系统回收的概率（常驻通知栏「小蓝在你身边」）；
- **开机提醒**：`BootReceiver` 开机后发一条「小蓝在等你」，点一下就能回来；
- **应用图标**：用桌宠本体渲染的 `ic_launcher.png`。

## 关键代码

```java
EasyFloat.with(this)
        .setLayout(R.layout.float_pet)
        .setShowPattern(ShowPattern.ALL_TIME)   // 系统浮窗
        .setSidePattern(SidePattern.RESULT_HORIZONTAL)
        .setDragEnable(true)
        .setTag("xiaolan")
        .show();
```

## 编译

推到 GitHub 后由 `.github/workflows/build.yml` 自动 `gradle assembleDebug`，
在 Actions 的 Artifacts 里下载 APK。

## 依赖

EasyFloat 2.0.4（JitPack）、androidx.appcompat 1.6.1、kotlin-stdlib 1.9.22
